package com.stringCalculator;
public class ExceptionsNotAllowed extends Exception{
   
	private static final long serialVersionUID = -1438524487448939071L;

	ExceptionsNotAllowed(String message){
        super(message);
    }

}